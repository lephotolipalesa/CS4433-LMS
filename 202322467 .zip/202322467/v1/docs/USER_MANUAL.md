# Role User Manual

## Administrator
Log in with the initial administrator credentials. Create departments first. Create users and assign department IDs for lecturers, HoDs and students. Create courses, assign lecturer user IDs, enrol student user IDs. Use list functions to verify IDs. Deactivate accounts when access should end; do not delete accounts because historical marks/audit entries reference them.

## Lecturer
The administrator must assign you to a course. Create an assignment using a deadline in `YYYY-MM-DD HH:MM:SS` and a positive maximum mark. View submissions. Mark using a raw score within 0..maximum and provide written feedback plus a reason. The final mark applies the recorded late penalty. Use the extension options for an individual student or the whole class; the student's assignment list displays the effective deadline.

## Head of Department
Your account must have the department ID corresponding to the courses. View the moderation queue. Approve or return each pending mark with a comment. Only approved marks can be released. Use the audit log to inspect mark changes.

## Student
The administrator must enrol you in a course. View the assignment list and effective deadline. Submit a path to your work and a submission timestamp; resubmissions create new versions. View marks and feedback only after the HoD releases them.

## Common guidance
Choose Logout to return to the login prompt. Use `q` at the username prompt to exit. If an operation is rejected, read the message and ask the administrator/lecturer to correct the setup. Do not share credentials. The application is console-based and works offline.
