# Test Execution Record

**Execution environment:** Linux x86_64, GCC 14.2.0, CMake 3.31.8, SQLite 3.46.1, OpenSSL 3.5.7. This is the assistant build environment, not the student's Windows/MSYS2 workstation.

**Commands executed:**
```bash
cmake -S . -B build -G Ninja
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

**Observed result:** CMake configuration succeeded; both application and test executable compiled and linked; CTest reported 1/1 test target passed. The test executable reported 19 PASS assertions and 0 failures. Covered assertions include penalty boundaries (0–4 days), exact/partial deadline boundaries, role factory/polymorphism, salted password hash/verification, SQLite registration/login, class-wide extension visibility, lecturer submission visibility, hiding unreleased marks, release visibility and audit reason persistence.

**Limitations:** These tests are a small self-contained C++ test harness, not GoogleTest or Catch2. No measured line-coverage report was generated; the 70% target is therefore not yet demonstrated. Static analysis was not run because cppcheck/clang-tidy was not installed in this execution environment. The GitHub Actions workflow is included but has not run in the student's remote repository. Re-run on the target MSYS2 UCRT64 machine and retain screenshots/logs as submission evidence.
