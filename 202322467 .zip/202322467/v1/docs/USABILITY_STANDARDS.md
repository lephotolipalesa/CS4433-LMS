# Console Interface Usability Standards

The LMS uses a simple, consistent console interface designed to reduce input errors and make each role's tasks easier to find.

## Standards applied

1. **Consistency:** All roles use the same application heading, menu structure, numbered choices, prompt style and return-to-menu behaviour.
2. **Visibility of system status:** Successful operations display a confirmation. Failed operations display a plain-language explanation.
3. **Error prevention:** Numeric inputs are validated; invalid menu choices are rejected; account deactivation requires explicit confirmation.
4. **User control:** Each role can log out using option 0. Users are returned to the relevant menu after an operation.
5. **Recognition rather than recall:** Menu choices are displayed with descriptive labels rather than requiring users to memorise commands.
6. **Help users recover from errors:** Error messages explain that an operation was not completed and display the reason where available.
7. **Readable presentation:** Menus are grouped under meaningful headings, with spacing and separators to make options easier to scan.

## Scope and limitations

This is a console application, not a graphical interface. It does not currently provide mouse interaction, resizable panels, screen-reader-specific semantics, or configurable text size. These limitations should be considered during accessibility evaluation. The interface avoids relying on colour alone to communicate information.

## Suggested usability checks

- Ask a first-time user to sign in and find their role's main tasks without assistance.
- Enter letters where a number is requested and confirm that the program asks again.
- Select an unavailable menu option and confirm that the menu remains usable.
- Attempt to deactivate an account and choose not to confirm; verify that no change occurs.
- Complete an operation and confirm that the success message is understandable.
