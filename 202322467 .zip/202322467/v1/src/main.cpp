#include "lms/core.hpp"
#include <iostream>
using namespace lms;
namespace {
std::string ask(const std::string& p) { std::cout << p; std::string s; std::getline(std::cin, s); return s; }
int num(const std::string& p) { for (;;) { auto s=ask(p); try { size_t n=0; int v=std::stoi(s,&n); if(n==s.size()) return v; } catch(...) {} std::cout<<"Enter a valid whole number.\n"; } }
double dec(const std::string& p) { for (;;) { auto s=ask(p); try { size_t n=0; double v=std::stod(s,&n); if(n==s.size()) return v; } catch(...) {} std::cout<<"Enter a valid number.\n"; } }
Role getRole() { int r=num("Role (1 Admin, 2 Lecturer, 3 HoD, 4 Student): "); if(r<1||r>4) throw std::runtime_error("Role must be 1-4"); return static_cast<Role>(r-1); }
}
int main() {
 try {
  LMS app;
  if(!app.hasUsers()) { std::cout<<"=== Moderated LMS first-time setup ===\n"; app.createInitialAdmin(ask("Admin username: "),ask("Admin password (min 8 chars): ")); std::cout<<"Administrator created.\n"; }
  for(;;) {
   std::cout<<"\n=== Moderated LMS ===\n"; auto username=ask("Username (q to quit): "); if(username=="q"||username=="Q") break;
   auto user=app.login(username,ask("Password: ")); if(!user) { std::cout<<"Login failed. Check credentials or account status.\n"; continue; }
   std::cout<<"\nWelcome, "<<user->username()<<" — "<<user->dashboard()<<"\n"; bool active=true;
   while(active) {
    try {
     switch(user->role()) {
      case Role::Admin: {
       std::cout<<"\n1 Create department  2 Create user  3 Create course  4 Assign lecturer  5 Enrol student  6 List users  7 List courses  8 Deactivate user  0 Logout\n";
       int c=num("Choice: "); if(c==0)active=false; else if(c==1)app.createDepartment(*user,ask("Department name: ")); else if(c==2)app.createUser(*user,ask("Username: "),ask("Temporary password: "),getRole(),num("Department ID (0 for none): ")); else if(c==3)app.createCourse(*user,num("Department ID: "),ask("Course code: "),ask("Course title: ")); else if(c==4)app.assignLecturer(*user,num("Course ID: "),num("Lecturer user ID: ")); else if(c==5)app.enrolStudent(*user,num("Course ID: "),num("Student user ID: ")); else if(c==6)std::cout<<app.listUsers(*user); else if(c==7)std::cout<<app.listCourses(*user); else if(c==8)app.deactivateUser(*user,num("User ID: ")); else std::cout<<"Invalid choice.\n"; break;
      }
      case Role::Lecturer: {
       std::cout<<"\n1 Create assignment  2 List submissions  3 Mark submission  4 Extend deadline for one student  5 Extend deadline for whole class  0 Logout\n";
       int c=num("Choice: "); if(c==0)active=false; else if(c==1)app.createAssignment(*user,num("Course ID: "),ask("Title: "),ask("Deadline YYYY-MM-DD HH:MM:SS: "),dec("Maximum mark: ")); else if(c==2)std::cout<<app.lecturerSubmissions(*user); else if(c==3)app.mark(*user,num("Submission ID: "),dec("Raw mark: "),ask("Written feedback: "),ask("Reason for mark/change: ")); else if(c==4)app.extendDeadline(*user,num("Assignment ID: "),num("Student ID: "),ask("New deadline YYYY-MM-DD HH:MM:SS: "),ask("Reason: ")); else if(c==5)app.extendDeadline(*user,num("Assignment ID: "),std::nullopt,ask("New class deadline YYYY-MM-DD HH:MM:SS: "),ask("Reason: ")); else std::cout<<"Invalid choice.\n"; break;
      }
      case Role::HoD: {
       std::cout<<"\n1 View moderation queue  2 Approve mark  3 Return mark to lecturer  4 Release approved mark  5 View audit log  0 Logout\n";
       int c=num("Choice: "); if(c==0)active=false; else if(c==1)std::cout<<app.moderationQueue(*user); else if(c==2)app.moderate(*user,num("Submission ID: "),true,ask("Moderation comment: ")); else if(c==3)app.moderate(*user,num("Submission ID: "),false,ask("Reason for return: ")); else if(c==4)app.release(*user,num("Submission ID: ")); else if(c==5)std::cout<<app.auditLog(*user); else std::cout<<"Invalid choice.\n"; break;
      }
      case Role::Student: {
       std::cout<<"\n1 View assignment list  2 Submit/resubmit assignment  3 View released marks and feedback  0 Logout\n";
       int c=num("Choice: "); if(c==0)active=false; else if(c==1)std::cout<<app.studentAssignments(*user); else if(c==2)app.submit(*user,num("Assignment ID: "),ask("Path to submission file: "),ask("Submission timestamp YYYY-MM-DD HH:MM:SS: ")); else if(c==3)std::cout<<app.releasedMarks(*user); else std::cout<<"Invalid choice.\n"; break;
      }
     }
    } catch(const std::exception& e) { std::cout<<"Operation not completed: "<<e.what()<<"\n"; }
   }
   std::cout<<"Logged out. Goodbye.\n";
  }
 } catch(const std::exception& e) { std::cerr<<"Fatal error: "<<e.what()<<"\n"; return 1; }
 return 0;
}
