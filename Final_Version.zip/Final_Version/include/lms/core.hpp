#pragma once
#include <sqlite3.h>
#include <string>
#include <vector>
#include <memory>
#include <optional>
#include <stdexcept>
namespace lms {
enum class Role { Admin, Lecturer, HoD, Student };
std::string roleName(Role role);
std::unique_ptr<class User> makeUser(int id,const std::string& username,Role role,int departmentId);
class User { public: User(int id,std::string u,Role r,int d):id_(id),username_(std::move(u)),role_(r),department_(d){} virtual ~User()=default; virtual std::string dashboard() const=0; int id()const{return id_;} int department()const{return department_;} Role role()const{return role_;} const std::string& username()const{return username_;} private:int id_;std::string username_;Role role_;int department_;};
class Administrator final:public User{public:using User::User;std::string dashboard()const override;};
class Lecturer final:public User{public:using User::User;std::string dashboard()const override;};
class HeadOfDepartment final:public User{public:using User::User;std::string dashboard()const override;};
class Student final:public User{public:using User::User;std::string dashboard()const override;};
class LatePenaltyStrategy {public:virtual ~LatePenaltyStrategy()=default;virtual double fraction(int daysLate)const=0;};
class TenPercentPerDay final:public LatePenaltyStrategy{public:double fraction(int daysLate)const override;};
int daysLate(const std::string& due,const std::string& submitted);
class Database { sqlite3* db_=nullptr; public: explicit Database(const std::string& path);~Database();Database(const Database&)=delete;Database& operator=(const Database&)=delete;sqlite3* handle()const{return db_;}void initialise();};
class LMS {
 Database db_; TenPercentPerDay penalty_;
 void exec(const std::string& sql); int scalar(const std::string& sql);
 bool hasRole(int userId,Role role); int effectiveDeadlineDays(int assignmentId,int studentId,const std::string& submittedAt);
 public:
 explicit LMS(const std::string& dbPath="lms.db");
 bool hasUsers(); void createInitialAdmin(const std::string& username,const std::string& password);
 std::unique_ptr<User> login(const std::string& username,const std::string& password);
 void createUser(const User& actor,const std::string& username,const std::string& password,Role role,int departmentId);
 void deactivateUser(const User& actor,int userId);
 void createDepartment(const User& actor,const std::string& name);
 void createCourse(const User& actor,int departmentId,const std::string& code,const std::string& title);
 void assignLecturer(const User& actor,int courseId,int lecturerId);
 void enrolStudent(const User& actor,int courseId,int studentId);
 void createAssignment(const User& actor,int courseId,const std::string& title,const std::string& deadline,double maxMark);
 void extendDeadline(const User& actor,int assignmentId,std::optional<int> studentId,const std::string& newDeadline,const std::string& reason);
 void submit(const User& actor,int assignmentId,const std::string& filePath,const std::string& submittedAt);
 void mark(const User& actor,int submissionId,double rawMark,const std::string& feedback,const std::string& reason);
 void moderate(const User& actor,int submissionId,bool approve,const std::string& comment);
 void adjustMark(const User& actor,int submissionId,double newFinalMark,const std::string& reason);
 void release(const User& actor,int submissionId);
 std::string studentAssignments(const User& actor);
 std::string lecturerSubmissions(const User& actor);
 std::string lecturerCourses(const User& actor);
 std::string lecturerAssignments(const User& actor);
 std::string moderationQueue(const User& actor);
 std::string releasedMarks(const User& actor);
 std::string auditLog(const User& actor);
 std::string listUsers(const User& actor);
 std::string listDepartments(const User& actor);
 std::string listCourses(const User& actor);
};
std::string hashPassword(const std::string& password);
bool verifyPassword(const std::string& password,const std::string& encoded);
}
