#include "lms/core.hpp"
#include <iostream>
#include <cstdio>
#include <stdexcept>
using namespace lms;
int main(){int failed=0;auto check=[&](bool ok,const char*name){if(ok)std::cout<<"PASS: "<<name<<"\n";else{std::cout<<"FAIL: "<<name<<"\n";++failed;}};
 TenPercentPerDay p;check(p.fraction(0)==0.0,"on-time penalty is zero");check(p.fraction(1)==0.10,"one day late is 10 percent");check(p.fraction(2)==0.20,"two days late is 20 percent");check(p.fraction(3)>0.299999&&p.fraction(3)<0.300001,"three days late is 30 percent");check(p.fraction(4)==1.0,"more than three days late is zero mark");
 check(daysLate("2026-11-01 12:00:00","2026-11-01 12:00:00")==0,"deadline instant is on time");check(daysLate("2026-11-01 12:00:00","2026-11-01 12:00:01")==1,"partial late day rounds up");
 bool invalidDateRejected=false;try{(void)daysLate("2026-02-30 12:00:00","2026-02-30 12:00:00");}catch(const std::exception&){invalidDateRejected=true;}
 check(invalidDateRejected,"impossible calendar dates are rejected");
 auto u=makeUser(1,"x",Role::Student,1);check(u->dashboard()=="Student dashboard","factory creates polymorphic Student");auto admin=makeUser(2,"a",Role::Admin,0);check(admin->dashboard()=="Administrator dashboard","factory creates polymorphic Administrator");
 auto h=hashPassword("TestingPass123");check(h!="TestingPass123","password is not stored as plaintext");check(verifyPassword("TestingPass123",h),"correct password verifies");check(!verifyPassword("WrongPassword",h),"wrong password rejected");
 std::remove("lms_test.db");try{LMS db("lms_test.db");db.createInitialAdmin("admin","AdminPass123");auto logged=db.login("admin","AdminPass123");check(logged&&logged->role()==Role::Admin,"SQLite registration and login integration");check(!db.login("admin","incorrect"),"SQLite rejects incorrect password");
 auto admin=db.login("admin","AdminPass123"); db.createDepartment(*admin,"Science");
 db.createUser(*admin,"lecturer","LecturerPass1",Role::Lecturer,1); db.createUser(*admin,"hod","HeadPass123",Role::HoD,1); db.createUser(*admin,"student","StudentPass1",Role::Student,0);
 auto lecturer=db.login("lecturer","LecturerPass1"); auto hod=db.login("hod","HeadPass123"); auto student=db.login("student","StudentPass1");
 db.createCourse(*admin,1,"SCI101","Science"); db.assignLecturer(*admin,1,2); db.enrolStudent(*admin,1,4);
 db.createAssignment(*lecturer,1,"Test Assignment","2026-11-01 12:00:00",100.0);
 db.extendDeadline(*lecturer,1,std::nullopt,"2026-11-03 12:00:00","School closure");
 check(db.studentAssignments(*student).find("2026-11-03 12:00:00")!=std::string::npos,"class extension appears on student assignment list");
 db.extendDeadline(*lecturer,1,4,"2026-11-02 12:00:00","Individual arrangement");
 check(db.studentAssignments(*student).find("2026-11-02 12:00:00")!=std::string::npos,"individual extension takes precedence over a later class extension");
 db.submit(*student,1,"submissions/student1.txt","2026-11-02 12:00:00");
 check(db.lecturerSubmissions(*lecturer).find("SUBMITTED")!=std::string::npos,"student submission is visible to assigned lecturer");
 db.mark(*lecturer,1,80.0,"Good work","Initial marking");
 check(db.releasedMarks(*student).find("Test Assignment")==std::string::npos,"unreleased marks are hidden from student");
 db.adjustMark(*hod,1,75.0,"HoD moderation adjustment");
 db.moderate(*hod,1,true,"Checked"); db.release(*hod,1);
 check(db.releasedMarks(*student).find("Test Assignment")!=std::string::npos,"approved mark is visible after HoD release");
 check(db.releasedMarks(*student).find("75 | 100")!=std::string::npos,"HoD adjustment changes the final mark before release");
 check(db.auditLog(*hod).find("Initial marking")!=std::string::npos,"mark audit records reason and actor");
 check(db.auditLog(*hod).find("HoD moderation adjustment")!=std::string::npos,"HoD mark adjustment is recorded in the audit trail");
 check(db.releasedMarks(*student).find("HoD moderation adjustment")==std::string::npos,"student sees released mark and release metadata, not internal audit reasons");
 check(db.releasedMarks(*student).find("RELEASED BY")!=std::string::npos,"released result identifies release time and releasing HoD");
 db.createAssignment(*lecturer,1,"Very Late Assignment","2026-11-01 12:00:00",100.0);
 db.submit(*student,2,"submissions/late.txt","2026-11-05 12:00:00");
 check(db.lecturerSubmissions(*lecturer).find("LATE")!=std::string::npos,"submission more than three days late is accepted and labelled late");
 db.mark(*lecturer,2,80.0,"Late work","Late penalty applied");
 db.moderate(*hod,2,true,"Reviewed"); db.release(*hod,2);
 check(db.releasedMarks(*student).find("0 | 100")!=std::string::npos,"submission more than three days late receives zero under the penalty rule");
 bool lateResubmitRejected=false;try{db.submit(*student,2,"submissions/late-v2.txt","2026-11-06 12:00:00");}catch(const std::exception&){lateResubmitRejected=true;}
 check(lateResubmitRejected,"resubmission after the effective deadline is rejected without replacing the saved version");
 db.createAssignment(*lecturer,1,"One Day Late Assignment","2026-11-01 12:00:00",100.0);
 db.submit(*student,3,"submissions/one-day-late.txt","2026-11-02 12:00:00");
 db.mark(*lecturer,3,80.0,"Good work","One day late penalty"); db.moderate(*hod,3,true,"Reviewed"); db.release(*hod,3);
 check(db.releasedMarks(*student).find("70 | 100")!=std::string::npos,"one late day deducts 10 percentage points of maximum mark");
 check(db.listDepartments(*admin).find("Science")!=std::string::npos,"administrator can view departments for selection");
 check(db.listUsers(*admin).find("Science")!=std::string::npos,"user list displays department names rather than requiring department ID recall");
 check(db.studentAssignments(*student).find("MAX MARK")!=std::string::npos,"student assignment dashboard includes maximum marks and useful deadlines");
 check(db.moderationQueue(*hod).find("STUDENT ID")!=std::string::npos,"moderation queue displays identifying context before selection");
 db.createDepartment(*admin,"Arts");db.createUser(*admin,"hodarts","ArtsHead123",Role::HoD,2);auto artsHod=db.login("hodarts","ArtsHead123");
 check(db.auditLog(*artsHod).find("Initial marking")==std::string::npos,"HoD audit view is restricted to their own department");
 bool selfDeactivateRejected=false;try{db.deactivateUser(*admin,admin->id());}catch(const std::exception&){selfDeactivateRejected=true;}
 check(selfDeactivateRejected,"administrator cannot accidentally deactivate their own active session");
 bool duplicateEnrolmentRejected=false;try{db.enrolStudent(*admin,1,4);}catch(const std::exception&){duplicateEnrolmentRejected=true;}
 check(duplicateEnrolmentRejected,"duplicate enrolment produces an explicit validation error");
 }catch(const std::exception&e){std::cout<<"Integration test error: "<<e.what()<<"\n";++failed;}std::remove("lms_test.db");std::cout<<"Failures: "<<failed<<"\n";return failed?1:0;}
