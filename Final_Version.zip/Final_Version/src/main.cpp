#include "lms/core.hpp"
#include <iostream>
#include <limits>
#include <string>
#include <functional>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

using namespace lms;
namespace {
struct Back{}; struct Cancel{}; struct Restart{}; struct Exit{}; struct Logout{};
std::string read(const std::string& prompt) {
    std::cout << prompt;
    std::string value;
    if (!std::getline(std::cin, value)) throw Exit{};
    if (value == ":back") throw Back{};
    if (value == ":cancel") throw Cancel{};
    if (value == ":restart") throw Restart{};
    if (value == ":exit") throw Exit{};
    if (value == ":help") {
        std::cout << "Commands: :back (return to dashboard), :cancel (cancel this task),\n"
                     "          :restart (restart this task), :undo (clear this answer), :exit (quit).\n";
        return read(prompt);
    }
    if (value == ":undo") {
        std::cout << "Current answer cleared. Please enter it again. Earlier saved records are not changed.\n";
        return read(prompt);
    }
    return value;
}
int number(const std::string& prompt) {
    for (;;) {
        const auto v=read(prompt);
        try { std::size_t n=0; int x=std::stoi(v,&n); if(n==v.size()) return x; }
        catch (...) {}
        std::cout << "Enter a whole number (for example, 1). Your other answers are unchanged.\n";
    }
}
double decimal(const std::string& prompt) {
    for (;;) {
        const auto v=read(prompt);
        try { std::size_t n=0; double x=std::stod(v,&n); if(n==v.size()) return x; }
        catch (...) {}
        std::cout << "Enter a valid number. Your other answers are unchanged.\n";
    }
}
std::string required(const std::string& prompt) { for(;;){auto v=read(prompt);if(!v.empty())return v;std::cout<<"This field is required. Please enter a value.\n";} }
std::string passwordInput(const std::string& prompt) { for(;;){auto v=read(prompt);if(v.size()>=8)return v;std::cout<<"Use at least 8 characters. Your other answers are unchanged.\n";} }
int positiveNumber(const std::string& prompt) { for(;;){int v=number(prompt);if(v>0)return v;std::cout<<"Enter a number greater than zero.\n";} }
double positiveDecimal(const std::string& prompt) { for(;;){double v=decimal(prompt);if(v>0)return v;std::cout<<"Enter a number greater than zero.\n";} }
std::string dateTime(const std::string& prompt) { for(;;){auto v=read(prompt);try{(void)daysLate(v,v);return v;}catch(const std::exception&){std::cout<<"Enter a real date and time in YYYY-MM-DD HH:MM:SS format (for example, 2026-11-07 14:30:00). Your other answers are unchanged.\n";}} }
std::string now() {
    auto t=std::chrono::system_clock::to_time_t(std::chrono::system_clock::now()); std::tm tm{};
#ifdef _WIN32
    localtime_s(&tm,&t);
#else
    localtime_r(&t,&tm);
#endif
    std::ostringstream o; o<<std::put_time(&tm,"%Y-%m-%d %H:%M:%S"); return o.str();
}
void heading(const std::string& title,const std::string& subtitle={}) {
    std::cout << "\n============================================================\n"
                 "        MODERATED LEARNING MANAGEMENT SYSTEM\n"
                 "============================================================\n  " << title << "\n";
    if(!subtitle.empty()) std::cout<<"  "<<subtitle<<"\n";
    std::cout<<"------------------------------------------------------------\n";
}
void helpBar(){std::cout<<"\nNavigation: type :back, :cancel, :restart, :undo, :help or :exit at any prompt.\n";}
Role getRole(){
    for(;;){std::cout<<"[1] Administrator  [2] Lecturer  [3] Head of Department  [4] Student\n";
        int n=number("Role: "); if(n>=1&&n<=4)return static_cast<Role>(n-1);
        std::cout<<"Choose 1, 2, 3 or 4.\n";}
}
void pause(){std::cout<<"\nPress Enter to continue...";std::string s;std::getline(std::cin,s);}
void dashboard(LMS& app,const User& u){
    heading(u.dashboard(),"Welcome, "+u.username()+" | Role: "+roleName(u.role()));
    switch(u.role()){
    case Role::Admin:
        std::cout<<"YOUR WORKSPACE\n"<<"Departments:\n"<<app.listDepartments(u)<<"\nCourses:\n"<<app.listCourses(u)<<"\nAccounts:\n"<<app.listUsers(u); break;
    case Role::Lecturer:
        std::cout<<"YOUR COURSES\n"<<app.lecturerCourses(u)<<"\nYOUR ASSIGNMENTS\n"<<app.lecturerAssignments(u)<<"\nYOUR SUBMISSION ACTIVITY\n"<<app.lecturerSubmissions(u); break;
    case Role::HoD:
        std::cout<<"YOUR DEPARTMENT'S MODERATION QUEUE\n"<<app.moderationQueue(u); break;
    case Role::Student:
        std::cout<<"MY LEARNING OVERVIEW\n\nAssignments, deadlines and submission status:\n"
                 <<app.studentAssignments(u)<<"\nReleased marks and feedback:\n"<<app.releasedMarks(u)
                 <<"\nTip: use the assignment ID shown above when submitting work.\n"; break;
    }
    helpBar();
}
void menu(Role r){
    std::cout<<"\n";
    if(r==Role::Admin) std::cout<<"ACADEMIC SETUP\n [1] Create department\n [2] Create course\n [3] Assign lecturer to course\n [4] Enrol student in course\n\nUSER ACCOUNTS\n [5] Create user account\n [6] View users\n [7] View courses\n [8] Deactivate account\n";
    if(r==Role::Lecturer) std::cout<<"TEACHING AND ASSESSMENT\n [1] Create assignment\n [2] View submissions\n [3] Mark submission and give feedback\n [4] Extend one student's deadline\n [5] Extend a whole class deadline\n";
    if(r==Role::HoD) std::cout<<"MODERATION AND RESULTS\n [1] View moderation queue\n [2] Approve a mark\n [3] Return a mark to lecturer\n [4] Release an approved mark\n [5] View mark audit log\n [6] Adjust a mark before release\n";
    if(r==Role::Student) std::cout<<"MY LEARNING\n [1] View assignments and deadlines\n [2] Submit or resubmit work\n [3] View released marks and feedback\n";
    std::cout<<"\n [0] Log out\n [Q] Quit application\n";
}
void actionLoop(const std::function<void()>& action){
    for(;;){
        bool committed=false;
        try {
            action();
            committed=true;
            std::cout<<"\nTask completed. What would you like to do next?\n [1] Repeat this task\n [2] Return to dashboard\n [3] Log out\n";
            for(;;){
                int n=number("Choice: ");
                if(n==1)break;
                if(n==2)return;
                if(n==3)throw Logout{};
                std::cout<<"Choose 1, 2 or 3.\n";
            }
        } catch(const Restart&){
            if(committed){std::cout<<"This task has already been saved. Choose Repeat explicitly if you want to perform it again.\n";return;}
            std::cout<<"\nRestarting this unfinished task. No changes were saved.\n";continue;
        } catch(const Back&){std::cout<<"\nReturning to the dashboard.\n";throw;}
          catch(const Cancel&){
            if(committed)std::cout<<"\nThe completed task remains saved. Returning to the dashboard.\n";
            else std::cout<<"\nTask cancelled. No changes from this unfinished task were saved.\n";
            return;
        } catch(const std::exception& e){
            std::cout<<"\nThis action was not completed: "<<e.what()<<"\n [1] Retry this task  [2] Return to dashboard\n";
            if(number("Choice: ")==1)continue;
            return;
        }
        // The user explicitly chose Repeat after a successful commit.
    }
}
void confirm(const std::string& summary){std::cout<<"\nPLEASE REVIEW\n"<<summary<<"\n";auto a=read("Save these changes? [Y]es / [N]o: ");if(a!="Y"&&a!="y")throw Cancel{};}
}
int main(){
 try{
    LMS app;
    if(!app.hasUsers()){
        heading("FIRST-TIME SETUP","Create the first administrator account.");
        for(;;){try{auto u=required("Administrator username: ");auto p=passwordInput("Password (minimum 8 characters): ");confirm("Create the initial administrator account for '"+u+"'.");app.createInitialAdmin(u,p);std::cout<<"Administrator account created.\n";break;}catch(const Restart&){std::cout<<"Restarting setup.\n";}catch(const Back&){std::cout<<"Setup cancelled.\n";return 0;}catch(const Cancel&){std::cout<<"Setup cancelled. Close and relaunch when ready.\n";return 0;}}
    }
    bool quit=false;
    while(!quit){
        heading("SIGN IN","Enter your username and password. Enter Q as username to quit.");
        std::string username;
        try{username=read("Username: ");}catch(const Exit&){break;}catch(const Back&){continue;}catch(const Cancel&){continue;}catch(const Restart&){continue;}
        if(username=="q"||username=="Q")break;
        try{
            auto password=read("Password: ");auto user=app.login(username,password);
            if(!user){std::cout<<"Sign-in failed. Check your details or contact the administrator if your account is inactive.\n";auto retry=read("Press Enter to try again, or Q to quit: ");if(retry=="q"||retry=="Q")quit=true;continue;}
            bool loggedIn=true;
            while(loggedIn&&!quit){
                dashboard(app,*user);menu(user->role());
                int choice=0;
                try{auto c=read("Select an option: ");if(c=="q"||c=="Q"){quit=true;break;}try{choice=std::stoi(c);}catch(...){std::cout<<"Choose one of the displayed options.\n";continue;}}
                catch(const Back&){continue;}catch(const Cancel&){continue;}catch(const Restart&){continue;}
                catch(const Exit&){quit=true;break;}
                if(choice==0){loggedIn=false;break;}
                const int maxChoice = user->role()==Role::Admin ? 8 : user->role()==Role::Lecturer ? 5 : user->role()==Role::HoD ? 6 : 3;
                if(choice<1||choice>maxChoice){std::cout<<"That option is not available for your role. Choose one of the options displayed.\n";continue;}
                try{
                    if(user->role()==Role::Admin){
                        switch(choice){
                        case 1: actionLoop([&]{auto n=required("New department name: ");confirm("Create department: "+n);app.createDepartment(*user,n);std::cout<<"Department created.\n";});break;
                        case 2: actionLoop([&]{std::cout<<app.listDepartments(*user);int d=positiveNumber("Department ID from the list: ");auto c=required("Course code: ");auto t=required("Course title: ");confirm("Create course "+c+" - "+t+" in department "+std::to_string(d)+".");app.createCourse(*user,d,c,t);std::cout<<"Course created.\n";});break;
                        case 3: actionLoop([&]{std::cout<<app.listCourses(*user)<<"\n"<<app.listUsers(*user);int c=positiveNumber("Course ID: ");int l=positiveNumber("Lecturer user ID: ");confirm("Assign lecturer "+std::to_string(l)+" to course "+std::to_string(c)+".");app.assignLecturer(*user,c,l);std::cout<<"Lecturer assigned.\n";});break;
                        case 4: actionLoop([&]{std::cout<<app.listCourses(*user)<<"\n"<<app.listUsers(*user);int c=positiveNumber("Course ID: ");int s=positiveNumber("Student user ID: ");confirm("Enrol student "+std::to_string(s)+" in course "+std::to_string(c)+".");app.enrolStudent(*user,c,s);std::cout<<"Student enrolled.\n";});break;
                        case 5: actionLoop([&]{auto n=required("Username: ");auto p=passwordInput("Temporary password (minimum 8 characters): ");auto r=getRole();int d=0;if(r==Role::Lecturer||r==Role::HoD){std::cout<<app.listDepartments(*user);d=positiveNumber("Department ID: ");}confirm("Create account '"+n+"' with role "+roleName(r)+(d?" in department "+std::to_string(d):"") );app.createUser(*user,n,p,r,d);std::cout<<"Account created.\n";});break;
                        case 6: actionLoop([&]{std::cout<<app.listUsers(*user);});break;
                        case 7: actionLoop([&]{std::cout<<app.listCourses(*user);});break;
                        case 8: actionLoop([&]{std::cout<<app.listUsers(*user);int id=positiveNumber("User ID to deactivate: ");confirm("Deactivate user account "+std::to_string(id)+"?");app.deactivateUser(*user,id);std::cout<<"Account deactivated.\n";});break;
                        }
                    } else if(user->role()==Role::Lecturer){
                        switch(choice){
                        case 1: actionLoop([&]{std::cout<<app.lecturerCourses(*user);int c=positiveNumber("Course ID: ");auto t=required("Assignment title: ");auto due=dateTime("Deadline (YYYY-MM-DD HH:MM:SS): ");auto max=positiveDecimal("Maximum mark: ");confirm("Create '"+t+"' for course "+std::to_string(c)+", deadline "+due+", maximum mark "+std::to_string(max)+".");app.createAssignment(*user,c,t,due,max);std::cout<<"Assignment created.\n";});break;
                        case 2: actionLoop([&]{std::cout<<app.lecturerSubmissions(*user);});break;
                        case 3: actionLoop([&]{std::cout<<app.lecturerSubmissions(*user);int s=positiveNumber("Submission ID: ");double m=decimal("Raw mark: ");auto f=required("Feedback for student: ");auto reason=required("Reason for mark/change: ");confirm("Record mark "+std::to_string(m)+" for submission "+std::to_string(s)+" with feedback.");app.mark(*user,s,m,f,reason);std::cout<<"Mark saved for moderation; it is not yet visible to the student.\n";});break;
                        case 4: actionLoop([&]{std::cout<<app.lecturerAssignments(*user);int a=positiveNumber("Assignment ID: ");int s=positiveNumber("Student user ID: ");auto d=dateTime("New deadline (YYYY-MM-DD HH:MM:SS): ");auto r=required("Reason: ");confirm("Extend assignment "+std::to_string(a)+" for student "+std::to_string(s)+" to "+d+".");app.extendDeadline(*user,a,s,d,r);std::cout<<"Individual deadline updated.\n";});break;
                        case 5: actionLoop([&]{std::cout<<app.lecturerAssignments(*user);int a=positiveNumber("Assignment ID: ");auto d=dateTime("New class deadline (YYYY-MM-DD HH:MM:SS): ");auto r=required("Reason: ");confirm("Extend the whole class deadline for assignment "+std::to_string(a)+" to "+d+".");app.extendDeadline(*user,a,std::nullopt,d,r);std::cout<<"Class deadline updated.\n";});break;
                        }
                    } else if(user->role()==Role::HoD){
                        switch(choice){
                        case 1: actionLoop([&]{std::cout<<app.moderationQueue(*user);});break;
                        case 2: actionLoop([&]{std::cout<<app.moderationQueue(*user);int s=positiveNumber("Submission ID to approve: ");auto c=required("Moderation comment: ");confirm("Approve mark for submission "+std::to_string(s)+".");app.moderate(*user,s,true,c);std::cout<<"Mark approved. It can now be released.\n";});break;
                        case 3: actionLoop([&]{std::cout<<app.moderationQueue(*user);int s=positiveNumber("Submission ID to return: ");auto c=required("Reason for returning to lecturer: ");confirm("Return submission "+std::to_string(s)+" for correction.");app.moderate(*user,s,false,c);std::cout<<"Mark returned to lecturer.\n";});break;
                        case 4: actionLoop([&]{std::cout<<app.moderationQueue(*user);int s=positiveNumber("Approved submission ID to release: ");confirm("Release the approved mark for submission "+std::to_string(s)+" to the student.");app.release(*user,s);std::cout<<"Mark released to student.\n";});break;
                        case 5: actionLoop([&]{std::cout<<app.auditLog(*user);});break;
                        case 6: actionLoop([&]{std::cout<<app.moderationQueue(*user);int s=positiveNumber("Submission ID to adjust: ");double m=decimal("New final mark: ");auto r=required("Reason for adjustment: ");confirm("Adjust the final mark for submission "+std::to_string(s)+" to "+std::to_string(m)+". The change will be audited.");app.adjustMark(*user,s,m,r);std::cout<<"Mark adjusted and recorded in the audit log. Review/approval status is retained.\n";});break;
                        }
                    } else {
                        switch(choice){
                        case 1: actionLoop([&]{std::cout<<app.studentAssignments(*user);});break;
                        case 2: actionLoop([&]{std::cout<<app.studentAssignments(*user);int a=positiveNumber("Assignment ID shown above: ");auto path=required("Path to your submission file: ");confirm("Submit file '"+path+"' for assignment "+std::to_string(a)+"? The system records the current time.");app.submit(*user,a,path,now());std::cout<<"Submission recorded at "<<now()<<". Check the assignment list for its status.\n";});break;
                        case 3: actionLoop([&]{std::cout<<app.releasedMarks(*user);});break;
                        }
                    }
                }catch(const Back&){std::cout<<"Returned to dashboard.\n";}catch(const Logout&){loggedIn=false;std::cout<<"You have been signed out.\n";}catch(const Exit&){quit=true;}
            }
            if(!quit)std::cout<<"\nYou have been signed out.\n";
        }catch(const Exit&){quit=true;}catch(const Back&){std::cout<<"Returned to sign-in.\n";}catch(const Cancel&){std::cout<<"Sign-in cancelled.\n";}catch(const Restart&){std::cout<<"Restarting sign-in.\n";}
    }
    std::cout<<"\nThank you for using the Moderated Learning Management System.\n";
 }catch(const Exit&){std::cout<<"\nApplication closed safely.\n";return 0;}
  catch(const std::exception& e){std::cerr<<"\nThe application could not continue: "<<e.what()<<"\n";return 1;}
 return 0;
}
