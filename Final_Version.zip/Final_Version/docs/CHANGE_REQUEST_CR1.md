# Change Request CR1 — Whole-class assignment extension

## Request and classification

**Request:** A lecturer should be able to extend an assignment deadline for a whole class, and the revised deadline must appear on each affected student's assignment list.

**Classification:** Perfective maintenance. The request improves an existing deadline-extension capability rather than correcting a fault or adapting to a new platform.

## Impact analysis

| Artefact | Impact / update |
|---|---|
| FR-08 / extension requirements | Extend the requirement to cover both individual and whole-class deadline changes. |
| UC-02 / lecturer workflow | Add whole-class extension as a lecturer alternative action. |
| Student assignment use case | Display the effective deadline, not only the original deadline. |
| Class/design model | Extension operation accepts an optional student target; null target means the whole class. |
| Database | `extensions.student_id` is nullable; NULL identifies a class-wide extension. |
| Lecturer UI | Add a whole-class extension action and show the lecturer's assignments before selection. |
| Student UI | Display original deadline, effective deadline and submission status. |
| Tests | Verify class extension visibility, individual extension visibility, precedence, late calculation and regression of submissions. |

## Implementation

The existing database stores a class-wide extension with `student_id = NULL`. The lecturer console provides an option to extend a whole class. The student assignment query displays the effective deadline. If both an individual and class-wide extension exist, the individual extension takes precedence; otherwise the class-wide deadline applies. The core service calculates lateness against the same precedence rule.

## Verification and regression

The automated integration tests verify that a class extension appears in the student's assignment list, that an individual extension takes precedence over a later class-wide extension, and that the late penalty uses the effective deadline. Existing login, submission, marking, moderation, release and audit tests are rerun.

## Release

This change is included in the working v1.1 update. The project owner must create the Git tag `v1.1` in the hosted repository after target-environment regression tests pass. The tag has not been created by this package operation.
