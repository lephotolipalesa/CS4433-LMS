# Role User Manual — Moderated LMS

## Getting started

Run the application. On first launch, create the initial administrator account. Thereafter, sign in with your username and password. The application is keyboard-operated. Menu choices are numbered and role-specific.

### Navigation commands

You may enter these commands at a prompt:

- `:back` — leave the current unfinished task and return to your dashboard.
- `:cancel` — cancel the current unfinished task.
- `:restart` — start the current task again from its first question.
- `:undo` — clear the current answer and enter it again.
- `:help` — show the available commands.
- `:exit` — close the application.

An unfinished task is saved only after its review summary is confirmed. `:undo` does not reverse a previously saved database change. Saved marks and moderation decisions require an authorised, audited correction process.

## Administrator

1. Create departments before creating courses.
2. Create user accounts. A department is requested only for Lecturers and Heads of Department. Students are associated with courses through enrolment; they do not need a department assignment at account creation.
3. Create courses after selecting a department from the displayed department list.
4. Assign lecturers to courses and enrol students using the displayed course and user lists. The ID is shown with each record; you do not need to memorise it in advance.
5. View users and courses from the dashboard/menu.
6. Deactivate accounts only after checking the displayed user record and confirming the action.

## Lecturer

1. Use the dashboard's submission activity and the View Submissions option to see the submissions assigned to you.
2. Create assignments for courses assigned to you. Supply a title, deadline and maximum mark.
3. Mark a submission by selecting its displayed submission ID, entering a mark, providing feedback and a reason, then reviewing and confirming.
4. A saved mark is sent for moderation; it is not immediately visible to the student.
5. Grant an individual extension or a whole-class extension. Give the revised deadline and reason. The student's assignment list displays the effective deadline.

## Head of Department

1. The dashboard displays the moderation queue for your department.
2. Review the listed submission and mark details.
3. Approve a mark with a moderation comment or return it to the lecturer with a reason.
4. Release only an approved mark. Confirm the submission ID before release.
5. Use the audit log to inspect mark changes.

## Student

The dashboard is the main student workspace. It displays enrolled assignments, original and effective deadlines, maximum marks, submission status, and released marks/feedback. Released results also show when and by whom they were released.

1. Select View Assignments to inspect the current assignment list.
2. Select Submit or Resubmit and use the assignment ID shown in the list.
3. Enter the path to your work. The application records the current system time.
4. Review and confirm before saving.
5. Check the dashboard for the updated status. Marks appear only after the Head of Department releases them.

## After an operation

Choose Repeat to perform the same task again, Dashboard to return to your role workspace, or Log out to sign out. If validation fails, correct the displayed field; the application should not require you to restart the whole session.

## Important limitations

The current implementation stores the submitted file path, not a copy of the file. Confirm that the file remains available to the school computer. `:back` returns from the current task to the dashboard; field-by-field backward navigation is not yet available. `:undo` clears the current uncommitted answer only. Saved marks and moderation records are protected by the audit trail and cannot be erased through a generic undo command. HoD mark adjustments are supported before release; corrections after release need a separate authorised correction process.
