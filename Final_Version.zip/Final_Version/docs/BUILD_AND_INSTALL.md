# Moderated LMS — Build and Installation Guide

## Scope and platform
This is an offline C++17 console application using SQLite for persistent storage and OpenSSL PBKDF2-HMAC-SHA-256 for salted password hashing. It does not provide web/mobile interfaces, online payment, video conferencing, automated grading or plagiarism detection.

## Windows / MSYS2 UCRT64
1. Install MSYS2 and open **MSYS2 UCRT64** (not PowerShell).
2. Update packages: `pacman -Syu` (follow any restart instruction).
3. Install: `pacman -S --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja mingw-w64-ucrt-x86_64-sqlite3 mingw-w64-ucrt-x86_64-openssl mingw-w64-ucrt-x86_64-pkgconf`
4. Change directory to the extracted project folder. Example: `cd /c/Users/Lenovo/Downloads/CS4433_Weeks_4_5_6_Complete_Project`
5. Configure: `cmake -S . -B build -G Ninja`
6. Build: `cmake --build build`
7. Test: `ctest --test-dir build --output-on-failure`
8. Run: `./build/lms.exe`

## First run
The application asks you to create the initial administrator account. Use a unique test password of at least eight characters. The SQLite database `lms.db` is created in the current working directory. Back it up while the application is closed. Password hashes, not plaintext passwords, are stored.

## Typical setup sequence
1. Log in as administrator.
2. Create departments.
3. Create lecturer, HoD and student accounts, assigning each to a department.
4. Create courses; assign lecturers; enrol students.
5. Lecturer creates assignments and deadlines.
6. Student submits a file path and timestamp; subsequent submissions create a new immutable version row.
7. Lecturer marks and provides written feedback; mark changes create audit records.
8. HoD reviews, approves or returns the mark, then releases approved marks.
9. Student sees marks and feedback only after release.

## Date and file handling
Use ISO timestamps `YYYY-MM-DD HH:MM:SS`. Partial late days are rounded up. The submission record stores a file path; this console prototype does not copy the file into managed storage, so the school must keep submitted files in a controlled folder and maintain backups. The system trusts the timestamp supplied by the operator/student; production deployment should obtain timestamps from the system clock and validate file existence, type and size.

## Operational safeguards
Restrict OS access to the database and submission folder; use individual accounts; deactivate rather than delete accounts; back up the database daily; keep the machine clock correct; and test restore procedures. SQLite is appropriate for a single machine or modest local use; simultaneous multi-workstation deployment should be load-tested and may require a server database.
