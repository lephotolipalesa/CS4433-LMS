# Test Execution Record — HCI Update

**Execution environment:** Linux x86_64, GCC 14.2.0, CMake 3.31.8, SQLite 3.46.1, OpenSSL 3.5.7. This is the assistant build environment, not the student's target Windows/MSYS2 workstation.

**Commands executed:**
```bash
cmake -S . -B build
cmake --build build -j2
ctest --test-dir build --output-on-failure
```

**Observed result:** CMake configuration succeeded; application and test executable compiled and linked. CTest reported **1/1 test target passed**. The custom test runner reported **36 PASS assertions and 0 failures** (run `./build/lms_tests` for the detailed output). Added coverage includes student accounts without a department, visible department lists, department names in user listings, useful student assignment context, contextual moderation queue, department-scoped HoD audit access, prevention of self-deactivation, duplicate-enrolment feedback, impossible-date rejection, class-wide extension visibility and individual-extension precedence, acceptance of submissions more than three days late, zero mark after more than three late days, 10-percentage-point deduction per late day, rejection of resubmission after the effective deadline, HoD pre-release mark adjustment with audit, and recording/display of release time and releasing HoD. Existing checks cover password hashing, login, role factory, moderation/release visibility and mark audit.

**Important limitations:** The tests are a small self-contained C++ test harness, not GoogleTest or Catch2. No measured line-coverage report was generated; the 70% target is not demonstrated. Static analysis was not run in this environment. The hosted GitHub Actions workflow has not been verified against the student's remote repository. Run the build and tests on the target MSYS2 UCRT64 machine and retain the actual logs/screenshots. Formal usability acceptance testing has not yet been conducted.
