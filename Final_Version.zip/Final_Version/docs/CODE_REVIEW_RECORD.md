# Self Code Review Record

| Checklist item | Review status / action |
|---|---|
| Parameterised SQL | Prepared statements and bound values are used for user-supplied values. |
| Password storage | PBKDF2-HMAC-SHA-256 with a random 16-byte salt and 210,000 iterations; plaintext is not persisted. |
| Role enforcement | Service methods check the actor role before protected operations. |
| Department boundary | HoD moderation and release compare HoD department with course department. |
| Mark validation | Raw score must be between zero and assignment maximum. |
| Auditability | New/updated mark creates an audit row with actor, previous score (NULL for first mark), new score, reason and timestamp. |
| Resubmission history | New versions are inserted; prior version rows are not overwritten. |
| Student confidentiality | Student result query selects only marks in RELEASED state. |
| Persistence integrity | SQLite foreign keys, unique constraints and check constraints are enabled. |
| Exception handling | Service errors are caught at the console boundary and shown without terminating the session. |
| Follow-up review | Run cppcheck/clang-tidy, coverage and a second review on the target platform; record actual findings and fixes. |

This is a review checklist and implementation record, not a claim that an external reviewer or static analyser has approved the code.
