# HCI Design Justification — Moderated Learning Management System

## 1. Scope and design approach

The LMS remains a keyboard-operated C++17 console application. HCI quality is not dependent on using a graphical interface: the console still needs clear signifiers, consistent commands, useful feedback, recoverable errors, readable information and accessible interaction. The interface is designed for school users who may not be confident with computers.

The implementation provides role-specific dashboards, labelled menu choices, visible record lists, confirmation before high-impact changes, validation at the point of entry, and task-level navigation. Record identifiers remain in the database but are displayed beside meaningful names before selection; users should not have to memorise them.

## 2. Nielsen's ten usability heuristics

| Heuristic | Application in the LMS |
|---|---|
| 1. Visibility of system status | Success, failure, cancellation, submission status, moderation state and release state are stated in plain language. |
| 2. Match between system and real world | Menus use school vocabulary such as course, assignment, submission, feedback, lecturer and moderation rather than database terminology. |
| 3. User control and freedom | `:back`, `:cancel`, `:restart` and `:exit` are available at prompts. Unfinished tasks are not committed until confirmation. |
| 4. Consistency and standards | All roles share the same headings, menu numbering, prompt conventions, navigation vocabulary and confirmation pattern. |
| 5. Error prevention | Numeric input is validated; relevant records are displayed before IDs are entered; destructive actions require review and confirmation. |
| 6. Recognition rather than recall | Users see role-specific options and the relevant courses, users, assignments, submissions and departments before selecting records. |
| 7. Flexibility and efficiency of use | Experienced users can use short numeric choices; all tasks remain keyboard-operable and repeatable without logging in again. |
| 8. Aesthetic and minimalist design | Each dashboard prioritises the information and actions relevant to that role; unrelated functions are hidden from the role menu. |
| 9. Help users recognise, diagnose and recover from errors | Errors explain what failed and allow retry or return to the dashboard. Invalid numeric input repeats only that prompt. |
| 10. Help and documentation | Role-specific user guidance and an in-application command hint explain common actions and navigation. |

## 3. Shneiderman's eight golden rules

1. **Strive for consistency:** shared menu and prompt patterns are used across all roles.
2. **Seek universal usability:** plain language, keyboard-only operation, visible choices and no colour-only status indicators support a broad range of users.
3. **Offer informative feedback:** each completed or rejected operation explains its result.
4. **Design dialogs to yield closure:** task completion is followed by a next-step choice: repeat, dashboard or logout.
5. **Prevent errors:** inputs are validated and consequential actions are summarised before saving.
6. **Permit easy reversal of actions:** unfinished tasks can be cancelled or restarted; `:undo` clears the current uncommitted answer. Persistent academic actions are not silently reversed because that could damage the audit trail; a formal correction workflow is required for saved marks and releases.
7. **Keep users in control:** no automatic logout or unexpected return to sign-in occurs after a normal task.
8. **Reduce short-term memory load:** records are displayed before selection and IDs are shown with names and context.

## 4. Norman's seven principles

This document uses the seven principles commonly presented in Norman's design guidance: discoverability, feedback, conceptual model, affordances, signifiers, mappings and constraints.

| Principle | LMS application |
|---|---|
| Discoverability | The dashboard and role menu reveal available actions and current work. |
| Feedback | The application reports validation, save, cancellation, submission, moderation and release outcomes. |
| Conceptual model | The lifecycle is expressed in understandable states: submitted/late → marked → moderated/returned → released. |
| Affordances | Numbered menu choices and text prompts indicate the kind of response expected. |
| Signifiers | Labels such as `Course ID`, `Submission ID`, `Deadline` and `[1] Repeat` make the next action explicit. |
| Mappings | A displayed numbered option maps directly to the corresponding action; listed record IDs map to the record selected. |
| Constraints | Role-based menus and business-layer permission checks prevent unauthorised actions; validation constrains invalid marks and input formats. |

## 5. Six visual/interface design principles

The phrase “six design principles” can refer to several different design frameworks. For this console interface, the project adopts six practical information-design principles: **contrast, hierarchy, alignment, proximity, repetition and whitespace**. These are stated explicitly to avoid claiming an unspecified framework.

- **Contrast:** section headings, separators and labels distinguish content without relying on colour.
- **Hierarchy:** the role dashboard and task-relevant information appear before secondary actions.
- **Alignment:** IDs and record fields use consistent column labels and ordering.
- **Proximity:** related records and actions are grouped together (for example, course list beside course-selection prompts).
- **Repetition:** prompts, confirmations, error messages and navigation commands follow the same pattern.
- **Whitespace:** blank lines and separators reduce visual crowding in the terminal.

## 6. Seven principles of Universal Design

The seven principles from the Center for Universal Design are considered as follows:

1. **Equitable use:** the same core functionality is available through the keyboard to every role; access is controlled by job responsibility, not interface mode.
2. **Flexibility in use:** users can choose a displayed menu number or use the navigation commands; tasks can be repeated.
3. **Simple and intuitive use:** plain-language labels and role-specific dashboards reduce unnecessary complexity.
4. **Perceptible information:** status and errors are expressed in text, not colour alone; column headings identify information.
5. **Tolerance for error:** validation, confirmation, cancel and restart reduce the consequences of mistakes.
6. **Low physical effort:** the application uses ordinary keyboard input and avoids requiring mouse precision or repeated navigation to locate IDs.
7. **Size and space for approach and use:** a console cannot resize controls like a GUI, but the interface uses short lines, clear spacing and avoids requiring mouse interaction. Terminal zoom/font settings remain an operating-system accommodation.

## 7. Navigation and recovery command contract

| Command | Behaviour | Safety boundary |
|---|---|---|
| `:back` | Leave the current task and return to the previous dashboard/menu context. | Unconfirmed task data is not saved. |
| `:cancel` | Cancel the current task. | Unconfirmed task data is not saved. |
| `:restart` | Restart the current task from its first prompt. | The task commits only after final confirmation. |
| `:undo` | Clear the current uncommitted answer and prompt again. | It does not reverse a database transaction or erase an audit record. |
| `:help` | Show the available navigation commands and repeat the prompt. | No data is changed. |
| `:exit` | Close the application safely. | Any unconfirmed task is abandoned. |

A true undo of committed academic records is deliberately not implemented as a generic command. Reversing a mark, moderation decision or release must be a separate authorised correction operation that writes an audit entry. Treating a database delete as “undo” would undermine academic integrity and traceability.

## 8. Usability evaluation plan

Run one first-time-user scenario for each role. Ask users to (a) identify the next task, (b) locate the relevant record without memorising its ID, (c) enter an invalid value and recover, (d) cancel a task before confirmation, and (e) complete a normal task and choose the next action. Record task completion, time, assistance, errors and user comments. Do not claim usability success until this evaluation is actually run.

## 9. Known limitations requiring further work

- `:back` exits the current operation to the dashboard rather than moving one field backward through a multi-field form.
- `:undo` clears only the current uncommitted field; it does not undo earlier answers or committed database changes.
- Terminal screen-reader behaviour, high-contrast modes, keyboard remapping and adjustable text size depend partly on the terminal and operating system and have not been formally tested.
- A dedicated selection interface that lets users choose by displayed name instead of typing an ID remains a desirable improvement. Current lists display IDs to reduce recall burden, but some actions still require typing the displayed ID.
- Formal moderated usability testing is still required to verify effectiveness with representative students and staff.

## 10. References for the HCI frameworks

- Nielsen, J. (1994). *Usability Engineering*. Morgan Kaufmann. (Heuristic evaluation foundations.)
- Shneiderman, B., Plaisant, C., Cohen, M., Jacobs, S., Elmqvist, N. and Diakopoulos, N. (2016). *Designing the User Interface: Strategies for Effective Human-Computer Interaction*. 6th ed. Pearson.
- Norman, D. A. (2013). *The Design of Everyday Things: Revised and Expanded Edition*. Basic Books.
- Center for Universal Design (1997). *The Principles of Universal Design, Version 2.0*. North Carolina State University.
- W3C (2018). *Web Content Accessibility Guidelines (WCAG) 2.1*. These guidelines are primarily written for web content; they are a useful accessibility reference but are not a direct conformance claim for this console application.
