# Phase 1–8 Consistency Review and Remaining Work

This review compares the submitted Phase 1, Phase 2 and Phase 3 documents, the implementation supplied in the `Final` folder, and the CS4433 individual assignment brief. It distinguishes implemented work from work that still needs evidence or implementation.

## Phase 1 — Planning and management

**Present:** technical, operational, economic, legal and schedule feasibility discussion; overall recommendation; risk register with likelihood, impact, exposure, mitigation and owner. The document also contains an illustrated WBS and seven-week Gantt chart.

**Needs completion/evidence:**
- Verify that the Gantt chart clearly identifies every dependency, milestone and critical path (the chart is present, but the critical-path calculation should be explained in text).
- Update the risk register at each phase gate and record changed exposure/residual risk, not just the initial values.
- Include a clear project baseline and change-control record.

## Phase 2 — Requirements engineering

**Present:** stakeholder list, conflicts and proposed resolutions, 12 functional requirement entries, 6 measurable non-functional requirement entries, and three fully dressed use cases. An explicit use-case diagram is not evident among the supplied Phase 2 document images; a draft PlantUML use-case diagram has been added as `USE_CASE_MODEL.puml`.

**Needs completion/evidence:**
- Ensure there are at least 12 uniquely numbered functional requirements and 6 uniquely numbered measurable non-functional requirements, each with MoSCoW priority and a verification method.
- Reconcile the late-penalty wording. The implemented policy should be 10 percentage points of the maximum available mark per started late day for days 1–3, then zero after day 3; it is not a 10% reduction of the earned mark.
- The core submission service now enforces the rule that resubmission is allowed only before the effective deadline. The console records the local system timestamp automatically; the core API still accepts a timestamp argument for deterministic testing, so production callers must use the console/system clock path.
- Define whether the system stores an actual uploaded file or only a file path. Current code stores a path; it does not validate file existence, file type or file size.
- Confirm whether 10% means percentage points of maximum mark; this review follows the Phase 2 business-rule wording.

## Phase 3 — System design

**Present:** layered architecture and component diagrams, class diagram, state-machine diagram, activity diagram, two sequence diagrams, ERD, schema/data dictionary, and SOLID/pattern discussion are present as embedded diagrams/tables in the Phase 3 document. The issue is less absence than ensuring every diagram is legible, detailed enough for the marking rubric, and consistent with the final implementation.

**Needs completion/evidence:**
- Include complete, legible UML component, detailed class, state-machine, activity-with-swimlanes and both sequence diagrams.
- The current source uses a role factory and a late-penalty strategy, but the persistence code is implemented directly through SQLite statements inside the LMS service. A separate repository/DAO abstraction is not yet fully realised as described in the design rationale.
- Observer is described as a possible pattern, but an event/notification mechanism is not evident in the implementation. Either implement it or document it as a rejected/not-yet-used pattern rather than claiming it is implemented.
- Align the database data dictionary, table/field names and status transitions with the actual SQLite schema.
- Document how whole-class extensions are represented (nullable student_id) and how an individual extension takes precedence over the class extension.

## Phase 4 — Implementation

**Implemented in the updated application:** C++17, SQLite persistence, PBKDF2-HMAC-SHA256 salted password hashing through OpenSSL, parameterised SQLite statements, role subclasses/factory, role checks, course and enrolment management, assignment creation, individual/class extensions, versioned submissions, late-penalty calculation, mark audit, HoD mark adjustment before release, moderation, release metadata (time and releasing HoD), and transaction boundaries for submission, marking/audit, moderation, adjustment and release. The console now has role-specific dashboards, contextual record lists, confirmation, point-of-entry validation, task continuation and navigation commands. Department selection is requested only for Lecturer and HoD accounts. The HoD audit view is department-scoped.

**Still required:**
- Implement user-account editing to complete the full create/update/deactivate requirement.
- Add a formal correction-and-notification workflow for a mark that has already been released; the current HoD adjustment action is deliberately limited to pre-release marks.
- Decide whether submitted files should be copied into managed storage; the current system stores a path and does not validate file existence, type or size.
- Implement true selection by record name where possible; the current console displays IDs alongside meaningful names, but users still type the displayed ID.
- Add an assignment description/instructions field if the Phase 2 SRS retains it as mandatory.
- Define and test the chronological rule for extensions (for example, whether an extension earlier than the existing deadline should be rejected).
- Review password-hashing choice against the brief's “recognised library” wording. PBKDF2 is provided by OpenSSL and uses a random salt; justify the iteration count and consider Argon2id if supported by the target environment.

## Phase 5 — Verification and validation

**Present:** test plan with V-Model levels, boundary-value ideas, system scenarios, and an automated test executable. The custom C++ test runner currently reports 36 passing assertions, including late-submission boundaries, post-deadline resubmission rejection, role/department visibility, HoD mark adjustment and audit, release metadata, duplicate enrolment, self-deactivation protection and dashboard record context. The harness is not GoogleTest or Catch2.

**Still required:**
- Add automated tests for every Must requirement and all error/exception paths.
- Port tests to GoogleTest or Catch2 if required by the marking brief.
- Measure actual business-logic line coverage and report the measured figure; do not claim the 70% target without a report.
- Record actual system/acceptance testing, test environment, expected/actual results and defect retest evidence.
- Add failure-injection tests for transaction rollback and end-to-end cancellation/recovery paths.

## Phase 6 — Configuration management and quality assurance

**Present:** CMake project, GitHub Actions workflow, code review record and configuration QA documentation.

**Still required:**
- Provide the actual hosted repository URL, meaningful commit history, branch/pull-request evidence and v1.0/v1.1 tags.
- Run CI on the hosted repository and retain its result.
- Run cppcheck or clang-tidy and report findings and fixes.
- Record actual LOC and cyclomatic complexity for key functions.
- Complete a self-review checklist against the final code, not only a planned checklist.

## Phase 7 — Deployment

**Present:** build/install, deployment and user-manual documents.

**Still required:**
- Add the deployment UML diagram and release notes.
- Test the installation instructions on a clean target machine (ideally the intended MSYS2 UCRT64 environment).
- State exact compiler, CMake, SQLite and OpenSSL versions used for the tested build.
- Verify backup and restore of the SQLite database and document the database file location/permissions.
- Tag and package release v1.0 after acceptance checks pass.

## Phase 8 — Maintenance / CR1

**CR1:** whole-class assignment deadline extension and display of the revised deadline on the student's assignment list.

**Implemented:** the schema permits a class-wide extension (student_id is NULL), the lecturer workflow has a class extension option, and the student assignment list displays the effective deadline. Automated integration coverage checks that a class extension is visible to the student.

**Still required:**
- Complete a formal impact analysis linking CR1 to requirements, use cases, diagrams, classes, tables, source files and test cases.
- Update the design artefacts and traceability matrix.
- Regression coverage now verifies that an individual extension takes precedence when a class extension also exists.
- Run and document the full regression suite on the target Windows/MSYS2 environment, tag v1.1 and provide release notes.

## Professional, legal and ethical issues

The final report should identify the applicable Lesotho data-protection and privacy legislation using authoritative legal sources and avoid unsupported legal claims. Document access control, salted password storage, least privilege, auditability, retention/backup, incident handling, accessibility evaluation and the fairness rationale for the late penalty. The system should not expose student marks before HoD release.

## Traceability warning

The current traceability CSV is a useful starting point but is incomplete: it does not yet map every requirement to a specific design artefact and individual test case, and some entries use generic labels. Update it only after the remaining requirements and tests have been finalised. A draft use-case diagram and deployment diagram are now supplied as PlantUML source in `USE_CASE_MODEL.puml` and `DEPLOYMENT_DIAGRAM.puml`.
