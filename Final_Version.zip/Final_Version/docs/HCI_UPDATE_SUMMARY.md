# HCI Update Summary

This update preserves the C++17 console application and its SQLite database while making the interaction more usable and documenting the HCI rationale.

## Main source changes
- `src/main.cpp`: role-based dashboard content, visible record lists, input validation, confirmation dialogs, task continuation choices and navigation commands.
- `src/core.cpp`: department requirement limited to Lecturer/HoD, class/individual extension precedence, late-submission acceptance, percentage-point penalty calculation, strict date validation, resubmission cutoff, transaction boundaries, HoD pre-release mark adjustment/audit, department-scoped audit access, and release timestamp/actor metadata.
- `include/lms/core.hpp`: added department/course/assignment list operations used by the dashboards.
- `tests/test_core.cpp`: 36 passing assertions covering class/individual extensions, late submissions, penalties, resubmission cutoff, department selection and visibility, dashboard context, invalid dates, safe deactivation, HoD mark adjustment/audit, and release metadata.

## HCI documents
- `HCI_DESIGN_JUSTIFICATION.md`: Nielsen, Shneiderman, Norman, six interface-design and Universal Design mappings.
- `USABILITY_STANDARDS.md`: console interaction and accessibility scope.
- `USER_MANUAL.md`: revised role-by-role instructions and command reference.

## Assignment lifecycle documents
- `PHASE_REVIEW_AND_REMAINING_WORK.md`: review against Phases 1–8 and outstanding evidence.
- `CHANGE_REQUEST_CR1.md`: whole-class extension impact analysis and verification.
- `USE_CASE_MODEL.puml`: draft use-case diagram source.
- `DEPLOYMENT_DIAGRAM.puml`: deployment diagram source.
- `RELEASE_NOTES_v1.1.md`: working v1.1 release notes.

## Verification
The project builds with CMake in the supplied Linux environment. CTest reports 1/1 test target passed and the custom test runner reports 36 passing assertions. This is not a substitute for running the project on the required target environment, using GoogleTest/Catch2, generating measured coverage, running static analysis, or conducting formal user acceptance/usability testing.
