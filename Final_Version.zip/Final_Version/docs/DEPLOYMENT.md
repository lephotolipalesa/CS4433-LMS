# Deployment and Release Notes

## Deployment diagram (PlantUML)
```plantuml
@startuml
node "School workstation (offline)" {
  artifact "Moderated LMS console (C++17)" as app
  database "lms.db (SQLite)" as db
  folder "Controlled submissions folder" as files
  app --> db : SQLite / prepared statements
  app --> files : stores file path references
}
@enduml
```

## Release notes — v1.0
- C++17 offline console application.
- Four roles and role-specific menus.
- SQLite persistence and salted PBKDF2-HMAC-SHA-256 password hashes.
- Department/course setup, lecturer assignment, student enrolment.
- Assignment creation, individual and whole-class deadline extensions, submission version history.
- 10% of available mark deducted per late day for up to three days; after three days penalty is 100% (zero final mark).
- Lecturer marking/feedback, HoD moderation and controlled release.
- Mark audit log.
- Unit/integration test target and CTest integration.

## Versioning note
Tag `v1.0` only after local build, test, static analysis and acceptance evidence have been reviewed. The CR1 whole-class extension is implemented in this code baseline; if presenting v1.1, tag it only after documenting the change analysis and running regression tests. Do not claim a GitHub tag or CI run until it exists in your repository.
