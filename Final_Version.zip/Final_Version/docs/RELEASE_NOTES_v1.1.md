# Moderated LMS — Release Notes v1.1 (working update)

## Added
- Whole-class deadline extension for lecturers.
- Effective deadline shown on the student assignment list.
- Role-specific dashboard content, including a functional student learning overview.
- HCI navigation commands and review-before-save confirmation.
- Department and record lists to reduce reliance on remembering database IDs.

## Improved
- Department is requested only when creating a Lecturer or Head of Department account.
- Invalid numeric input is re-prompted without discarding other answers.
- Late work is accepted; the agreed penalty is applied during marking.
- Resubmission after the effective deadline is rejected without replacing the prior version.
- Individual extension takes precedence over class-wide extension.
- Submission/version, marking/audit, moderation and release updates use SQLite transactions.

## Known limitations
- The console still asks users to type the displayed ID in some workflows; selection by name is not yet implemented throughout.
- `:back` returns to the dashboard rather than stepping backward one field; `:undo` clears only the current uncommitted answer.
- A committed mark/release cannot be generically undone; an authorised correction workflow is required.
- File submission stores a path and does not copy or validate the file itself.
- GoogleTest/Catch2 migration, measured coverage, static analysis, formal usability testing, target-machine validation and hosted CI evidence remain outstanding.

## Release status

This is a working v1.1 source update. Do not label it a verified production release until the target environment, full regression suite, CI, static analysis and deployment checks have been completed and the Git tag has been created.
