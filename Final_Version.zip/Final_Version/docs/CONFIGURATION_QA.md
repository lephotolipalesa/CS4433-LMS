# Configuration Management and Quality Assurance

## Git strategy
- `main`: reviewed, buildable releases only.
- `develop`: integration branch.
- `feature/<requirement-id>-<short-name>`: one change per branch; merge through pull request after build/tests and self-review.
- Use meaningful commits such as `feat(FR-08): preserve resubmission versions` and `test(BR-02): cover late penalty boundaries`.
- Tag the baseline `v1.0`; tag the class-wide extension maintenance release `v1.1` after regression tests.

## CI
`.github/workflows/ci.yml` configures Windows MSYS2 UCRT64 and Ubuntu builds, then runs CTest on each push and pull request. CI results are evidence only after the workflow has actually run in the student's hosted repository.

## Static analysis
Run `cppcheck --enable=warning,performance,portability --inline-suppr --error-exitcode=1 src include` (install cppcheck first). Review all findings; document tool version, command, date, findings and fixes. Do not state zero findings unless the output supports it.

## Code review checklist
- Role check before each protected service operation.
- SQL uses prepared statements and bound parameters.
- Passwords are salted PBKDF2 hashes and are never logged.
- Mark range is validated against assignment maximum.
- Every mark insert/update creates an audit row with actor, old/new values, reason and timestamp.
- HoD department boundary is checked for moderation/release.
- Student results query filters `RELEASED` only.
- Resubmission creates a new version; previous version remains unchanged.
- Exceptions are caught at UI boundary; DB constraints protect persistent data.
- No credentials or real learner records in test fixtures/repository.

## Metrics
Record actual source LOC (`cloc` or `wc -l`), cyclomatic complexity (e.g. lizard), static-analysis findings, test count, pass/fail count and coverage. Metrics are environment- and tool-version-dependent; populate after running tools, do not fabricate them.
