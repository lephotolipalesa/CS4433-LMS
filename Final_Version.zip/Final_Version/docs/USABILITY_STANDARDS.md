# Console Interface Usability Standards

The interface follows the detailed HCI rationale in `HCI_DESIGN_JUSTIFICATION.md`.

## Interaction standards
- Each role receives a role-specific dashboard and only its permitted menu actions.
- Record lists display identifiers alongside meaningful names/context before a user is asked to select a record.
- Department selection is requested only when creating a Lecturer or Head of Department account. Students are associated with courses through enrolment; administrators do not need a department.
- Numeric and decimal inputs are validated at the prompt. An invalid value repeats that prompt without discarding earlier answers.
- High-impact operations display a review summary and require explicit confirmation before saving.
- After an operation, users can repeat it, return to the dashboard or log out.
- The navigation commands `:back`, `:cancel`, `:restart`, `:undo`, `:help` and `:exit` are available at prompts.
- Errors explain that the operation was not completed and display a recoverable reason where safe.
- Status is communicated through text and labels, never colour alone.

## Command semantics and limitations
- `:back`: abandon the current uncommitted task and return to the dashboard.
- `:cancel`: cancel the current uncommitted task.
- `:restart`: restart the current task from its first prompt.
- `:undo`: clear the current answer only. It does not reverse previous answers or committed database changes.
- `:help`: show command guidance and repeat the current prompt.
- `:exit`: close the application.

A committed mark, moderation decision or release is not silently reversible. A proper correction must be authorised and audited. The current console does not yet support moving backwards one field at a time in a multi-field form; `:back` returns to the dashboard. This limitation is recorded rather than overstating the feature.

## Accessibility scope
The application is keyboard-only and uses plain text, labelled prompts, consistent spacing and explicit status descriptions. Screen-reader compatibility, terminal high-contrast settings, adjustable font sizes and usability with users with disabilities have not been formally validated and must be evaluated in the target terminal environment.

## Suggested acceptance checks
1. First-time users in all four roles can identify their main tasks.
2. Users can locate the relevant record from a displayed list without memorising an ID beforehand.
3. Invalid numeric input does not discard earlier form entries.
4. `:cancel` and `:back` do not save an unconfirmed operation.
5. A user can repeat an operation or return to the dashboard after completion.
6. Student dashboard displays enrolled assignments, deadlines, effective deadlines, submission status and released marks/feedback.
7. Lecturer, HoD and administrator dashboards show role-relevant records.

Record actual participant results before claiming the usability acceptance target has been met.
