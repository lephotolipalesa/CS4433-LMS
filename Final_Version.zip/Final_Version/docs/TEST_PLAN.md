# Verification and Validation Test Plan

## V-Model mapping and gates
| V&V level | Design/requirements artefact verified | Entry criteria | Exit criteria |
|---|---|---|---|
| Unit | LatePenaltyStrategy, date calculations, password helper, role factory | Design Gate 2 approved; code builds | All boundary tests pass; no open critical defect |
| Integration | SQLite schema, authentication, enrolment, submission/version, marking/audit, moderation/release | Unit tests pass; test DB isolated | Persistence and foreign-key tests pass; role restrictions verified |
| System | Fully dressed Submit Assignment, Mark Submission, Moderate and Release use cases | Integrated build available | Main and exception paths pass; no severity-1/2 defect |
| Acceptance | Principal/lecturer/HoD/student/IT-officer scenarios | System tests pass; user manuals available | Stakeholder scenarios signed off; known limitations accepted |

## Equivalence partitions and boundary-value analysis
- Submission time: before deadline, exactly at deadline, one second after deadline, one day late, three days late, more than three days late.
- Mark: negative, zero, maximum, above maximum.
- Password: fewer than 8 characters, exactly 8, valid longer password, wrong password.
- Role: authorised actor and unauthorised actor for each operation.
- Extensions: no extension, individual extension, whole-class extension; effective deadline before/after original deadline.
- Submission versions: first submission and one or more resubmissions.

## Automated tests
Run `ctest --test-dir build --output-on-failure`. `lms_tests` covers penalty boundaries, date boundary behaviour, role factory/polymorphism, password hashing/verification and SQLite account/login integration. The current test executable is a lightweight self-contained harness so the starter builds without downloading test dependencies. For strict submission compliance, replace/port it to GoogleTest or Catch2 and attach a coverage report from a locally executed coverage build. Do not claim 70% coverage until measured.

## System/acceptance scenarios
1. Administrator creates department, users, course, lecturer assignment and student enrolment.
2. Unauthorised student attempts lecturer action; operation is rejected.
3. Lecturer creates assignment; invalid maximum mark is rejected.
4. Student submits on time and resubmits; both versions remain in `submission_versions`.
5. Lecturer marks within bounds; invalid marks are rejected; feedback is persisted.
6. Lecturer changes a mark with a reason; audit log captures actor, old/new mark, reason and timestamp.
7. HoD from another department cannot moderate/release the mark.
8. HoD returns a mark; lecturer can remark; HoD approves and releases.
9. Student cannot view unreleased mark; can view released mark and feedback.
10. Individual and whole-class extensions appear in assignment list and affect effective deadline.

## Defect log template
| ID | Severity | Description/cause | Fix | Retest result |
|---|---|---|---|---|
| D-001 | To be populated during execution | Record observed failure, not hypothetical defect | Commit/reference | Pass/Fail + evidence |

## Results and coverage
The test report must contain the actual output of CTest and actual line coverage. This package does not invent execution results or coverage figures. Run the tests on the target MSYS2 environment and record the terminal output. Use GCC `--coverage`/gcov or an equivalent supported coverage tool for measured business-logic coverage.
